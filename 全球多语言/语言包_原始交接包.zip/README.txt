MATBOX GLOBAL LOCALIZATION - CODEX HANDOFF V3
Date: 2026-09-02

CURRENT FORMAL DOCUMENT: DEV.docx
Status: Stage 9 PASS / READY_FOR_STAGE10
Features: LOC-F001..LOC-F020
Acceptance: AC-LOC-001..AC-LOC-040

NEW P0 IN V3
LOC-F020 Realtime Multilingual Chat & Mobile AI Command Bridge
- Customer online chat is multilingual. Original Message/Transcript is always preserved as Messaging/Communication SoT.
- Optional translation for human agents is a derived view/cache only. It never overwrites original chat.
- Customers/owners can command AI employees from mobile using text or voice.
- command_language is separate from target_output_language and target_locale. Example: Chinese mobile instruction can produce en-US customer-facing output.
- Web / mini-program / App / iPad / mobile command must resume the same traceable language context revision.
- Voice reuses Communication ASR/Transcript. Low-confidence language/transcript must clarify before high-risk action.
- Reconnect/retry/duplicate taps must be idempotent and must not duplicate AI tasks or sends.
- Language switching never changes canonical Product/SKU/Price/Quantity/Order/Task facts.
- Reuse existing Messaging, Communication, AI Employee, Task, Action Gateway, Quality, Provider, Cost and Release owners. Do not rebuild them.

OPEN REAL RUNTIME GATE
G-LOC-ST8-007 must be run in Stage10/11 on real Messaging + AI Runtime + mobile shell. It does not block Stage9 pre-development handoff.

FILES
DEV.docx     Formal development document (V1.2-RC)
DEV.pdf      Rendered QA artifact
features.json Logical Feature Registry
evidence.json Stage1-9 Evidence Ledger
readiness.json Stage10 RC5 readiness
poc.py / poc.log Existing 12/12 core contract reference POC
MANIFEST.json SHA-256 manifest

WINDOWS NOTE
This package intentionally uses short internal filenames to avoid Windows built-in ZIP path-length extraction failures.
