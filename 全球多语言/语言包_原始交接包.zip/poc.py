from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Dict, Optional, Tuple

SUPPORTED = ("zh-CN", "en", "vi-VN")
PLATFORM_DEFAULT = "zh-CN"


def canonicalize(locale: Optional[str]) -> Optional[str]:
    if not locale:
        return None
    x = locale.strip()
    aliases = {
        "zh": "zh-CN", "zh-cn": "zh-CN", "zh_CN": "zh-CN",
        "en-US": "en", "en-GB": "en", "en-IN": "en",
        "vi": "vi-VN", "vi-vn": "vi-VN", "vi_VN": "vi-VN",
    }
    return aliases.get(x, aliases.get(x.lower(), x if x in SUPPORTED else None))


def resolve_language(
    explicit_choice: Optional[str] = None,
    saved_user: Optional[str] = None,
    tenant_default: Optional[str] = None,
    browser: Optional[str] = None,
    market_default: Optional[str] = None,
    platform_default: str = PLATFORM_DEFAULT,
) -> str:
    """Stage-1 priority contract: explicit > saved > tenant > browser > market > platform."""
    for candidate in (
        explicit_choice,
        saved_user,
        tenant_default,
        browser,
        market_default,
        platform_default,
    ):
        c = canonicalize(candidate)
        if c in SUPPORTED:
            return c
    return PLATFORM_DEFAULT


UI = {
    "product.upload": {
        "zh-CN": "上传产品",
        "en": "Upload Product",
        "vi-VN": "Tải sản phẩm lên",
    },
    "action.download": {
        "zh-CN": "下载",
        "en": "Download",
        # deliberately omit vi-VN to exercise fallback
    },
}


def t(key: str, language: str, fallback: str = PLATFORM_DEFAULT) -> str:
    item = UI[key]
    return item.get(language) or item.get(fallback) or key


def digest(text: str) -> str:
    return sha256(text.encode("utf-8")).hexdigest()


@dataclass
class TranslationRecord:
    content_id: str
    source_language: str
    target_language: str
    source_hash: str
    translated_text: str
    status: str = "translated"


@dataclass
class ContentStore:
    # Source content is canonical and never overwritten by localized versions.
    source: Dict[str, Tuple[str, str]] = field(default_factory=dict)  # id -> (lang, text)
    translations: Dict[Tuple[str, str], TranslationRecord] = field(default_factory=dict)

    def upsert_source(self, content_id: str, source_language: str, text: str) -> None:
        old = self.source.get(content_id)
        self.source[content_id] = (source_language, text)
        if old and old[1] != text:
            new_hash = digest(text)
            for (cid, _), rec in self.translations.items():
                if cid == content_id and rec.source_hash != new_hash:
                    rec.status = "outdated"

    def save_translation(self, content_id: str, target_language: str, text: str) -> None:
        source_language, source_text = self.source[content_id]
        self.translations[(content_id, target_language)] = TranslationRecord(
            content_id=content_id,
            source_language=source_language,
            target_language=target_language,
            source_hash=digest(source_text),
            translated_text=text,
        )

    def read(self, content_id: str, language: str) -> Tuple[str, str]:
        source_language, source_text = self.source[content_id]
        if canonicalize(language) == canonicalize(source_language):
            return source_text, "source"
        rec = self.translations.get((content_id, canonicalize(language) or language))
        if rec and rec.status == "translated" and rec.source_hash == digest(source_text):
            return rec.translated_text, "translated"
        return source_text, "fallback-source"


def run_tests() -> None:
    tests = []
    def check(name, condition, detail=""):
        tests.append((name, bool(condition), detail))

    # 1 First visit: browser vi -> Vietnamese
    check("AC01 browser first-visit", resolve_language(browser="vi-VN") == "vi-VN")

    # 2 Saved preference overrides browser
    check("AC02 saved preference wins", resolve_language(saved_user="en", browser="vi-VN") == "en")

    # 3 Explicit selection overrides everything
    check("AC02 explicit choice wins", resolve_language(explicit_choice="zh-CN", saved_user="en", browser="vi-VN") == "zh-CN")

    # 4 Tenant default wins over browser when user has no preference
    check("AC priority tenant over browser", resolve_language(tenant_default="en", browser="vi-VN") == "en")

    # 5 UI translation + fallback
    check("AC04 UI localized", t("product.upload", "vi-VN") == "Tải sản phẩm lên")
    check("AC04 missing UI fallback", t("action.download", "vi-VN") == "下载")

    # Dynamic business content
    store = ContentStore()
    product_id = "product_88271"
    original = "北美黑胡桃木实木餐桌"
    store.upsert_source(product_id, "zh-CN", original)
    store.save_translation(product_id, "vi-VN", "Bàn ăn gỗ óc chó đen Bắc Mỹ nguyên khối")

    # 6 Same business object ID across locales
    vi_text, vi_state = store.read(product_id, "vi-VN")
    zh_text, zh_state = store.read(product_id, "zh-CN")
    check("AC05 same Product ID", product_id == "product_88271" and vi_state == "translated" and zh_state == "source")

    # 7 Original is preserved
    check("AC06 source preserved", zh_text == original and store.source[product_id][1] == original)

    # 8 Source change invalidates old translation
    store.upsert_source(product_id, "zh-CN", "北美黑胡桃木实木餐桌，榫卯结构")
    rec = store.translations[(product_id, "vi-VN")]
    check("AC07 stale translation invalidated", rec.status == "outdated")

    # 9 Outdated localized text is not served as current truth
    after, state = store.read(product_id, "vi-VN")
    check("AC07 outdated not served", state == "fallback-source" and after == "北美黑胡桃木实木餐桌，榫卯结构")

    # 10 Language and locale remain separable
    user_profile = {"language": "en", "locale": "en-IN", "currency": "INR", "timezone": "Asia/Kolkata"}
    check("AC08 language/locale separated", user_profile["language"] == "en" and user_profile["locale"] == "en-IN" and user_profile["currency"] == "INR")

    # 11 AI default response language follows preferred UI language; conversation override is separate
    preferred = "vi-VN"
    conversation_override = "en"
    ai_default = conversation_override or preferred
    check("AC09 AI conversation override", ai_default == "en")

    passed = sum(1 for _, ok, _ in tests if ok)
    for name, ok, detail in tests:
        print(f"{'PASS' if ok else 'FAIL'} | {name}{' | '+detail if detail else ''}")
    print(f"\nRESULT: {passed}/{len(tests)} PASS")
    if passed != len(tests):
        raise SystemExit(1)


if __name__ == "__main__":
    run_tests()
